#include <gtest/gtest.h>

#include "../include/player.hpp"

TEST(player, constructor) { 
    ccpp::game::Player player = ccpp::game::Player(); 

}

