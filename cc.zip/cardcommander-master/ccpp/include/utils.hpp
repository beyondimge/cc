#include <random>

namespace ccpp {
bool RandomDiscrete(unsigned int num);
}