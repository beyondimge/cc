#ifndef CCPP_BENCH_HPP
#define CCPP_BENCH_HPP

#include <array>

#include "card.hpp"

namespace ccpp {
namespace game {

// todo
enum class Position : int { First, Second, Third };


}  // namespace game
}  // namespace ccpp

#endif  // CCPP_BENCH_HPP