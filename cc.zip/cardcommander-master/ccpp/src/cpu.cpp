#ifndef CCPP_CPU_HPP
#define CCPP_GAME_HPP


namespace ccpp {
namespace game {

  

}  // namespace game
}  // namespace ccpp

#endif  // CCPP_CPU_HPP